package my_first_scala_project

class Frazione(n:Int, d:Int)
{
  private val num = n; 
  private val den = d; 
  
  require (d!=0);

  def this(n:Int) = this(n,1);
  
  override def toString = if(d==1) "" + n else n+" / " + d;
  
  def calcMCD(a:Int, b:Int) : Int =
  {
    if(a % b == 0)
      b;
    else
      calcMCD(b, a%b);
  }
  
  def minTerm : Frazione =
  {
    val mcd = calcMCD(num.abs, den.abs);
    val nuovoNum = num / mcd; 
    val nuovoDen = den/mcd; 
    
    new Frazione(nuovoNum, nuovoDen);
  }
  
  def sum(f:Frazione): Frazione = 
  {
    val n = this.num * f.den + this.den * f.num;
    val d = this.den * f.den;
    new Frazione(n,d).minTerm;
  }
  def +(f:Frazione) : Frazione = sum(f)
  def +(i: Int) : Frazione = sum(new Frazione(i));
  
  def mul(f:Frazione) : Frazione = 
  {
    val n = f.num * this.num; 
    val d = f.den * this.den; 
    
    new Frazione(n,d).minTerm;
  }
  def *(f:Frazione) = mul(f);
  
  def equals(f:Frazione) : Boolean = 
  {
    f.num * this.den == f.den * this.num;
  }
  
  def unary_-() : Frazione = 
  {
    new Frazione(-this.num, this.den);
  }
}

object Frazione 
{
  implicit def conv(i:Int) : Frazione = new Frazione(i); //nome irrilevante
  
  def main(args: Array[String])
  {
    val f1 = new Frazione(3,4); 
    println(f1);
    val f2 = new Frazione(2);
    println(f2);
    
    println(f1 + f2);  //da notare diversa invocazione del + (overloaded)
    println(f1.+(f2));
    println(f1 * f2);
    println(f1 + new Frazione(5,4));
    
    println(-f1);
    
    println(f1 + 3); // funziona con operatore + overloaded per interi
    println(3 + f1); // funziona solo se implicit conv definita
   
  }
}

